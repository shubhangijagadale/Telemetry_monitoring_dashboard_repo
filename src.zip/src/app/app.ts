import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
// Import your header component path accurately here
import { Dashboard } from './components/dashboard/dashboard';
@Component({
  selector: 'app-root', 
  standalone: true,
  imports: [CommonModule,RouterOutlet,Dashboard],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  // Application local tracking states bound to header interactions
  isLightTheme = signal<boolean>(false);
  lastUpdatedTime = signal<string>('10:15:05 AM');

  toggleTheme(): void {
    this.isLightTheme.update(current => !current);
  }

  exportToCSV(): void {
    console.log('CSV Exporting pipe triggered!');
  }

  exportToExcel(): void {
    console.log('Excel Exporting pipe triggered!');
  }
}
