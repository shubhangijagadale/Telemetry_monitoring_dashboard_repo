import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
// Removed provideClientHydration import as it is not needed for desktop apps

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes)
    // Removed provideClientHydration() to stop the NG0500 DOM mismatch error in Electron
  ]
};
