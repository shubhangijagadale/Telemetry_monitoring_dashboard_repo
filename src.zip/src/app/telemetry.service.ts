import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, timer } from 'rxjs';

export interface TelemetryDataPoint {
  time: string;
  value: number;
}

export interface MetricGroup {
  currentRawValue: number;
  unit: string;
  status: 'NORMAL' | 'WARNING' | 'CRITICAL';
  history: TelemetryDataPoint[];
}

export interface DashboardData {
  timestamp: string;
  velocity: MetricGroup;
  pressure: MetricGroup;
  temperature: MetricGroup;
}

@Injectable({
  providedIn: 'root'
})
export class TelemetryService {
  private dataSubject = new BehaviorSubject<DashboardData | null>(null);
  
  // ─── STABLE ORIGINAL FACTORY CONTEXT REFERENCE CORES ───
  private readonly ORIGINAL_VELOCITY = 185.4;
  private readonly ORIGINAL_PRESSURE = 1012.0;
  private readonly ORIGINAL_TEMPERATURE = 36.8;

  // ─── ACTIVE RUNTIME SIMULATION STATE CONTAINERS ───
  private currentVelocity = 185.4;
  private currentPressure = 1012.0;
  private currentTemperature = 36.8;

  // ─── STRICT ROLLING IN-MEMORY HISTORY DECK (BOUNDED TO MAX 100) ───
  private velocityHistory: TelemetryDataPoint[] = [];
  private pressureHistory: TelemetryDataPoint[] = [];
  private temperatureHistory: TelemetryDataPoint[] = [];
  
  // ─── SYSTEM UPDATE CYCLE STEP CALCULATOR COUNTER ───
  private updateCycleCount = 0;

  // constructor() {
  //   this.initializeStaticSeedDeck();
  //   this.executeIndefiniteSimulationEngine();
  // }

  constructor() {

  // Build initial history
  this.initializeStaticSeedDeck();

  // Immediately send data to subscribers
  this.publishTelemetry();

  // Start realtime simulation
  this.executeIndefiniteSimulationEngine();

}
  /**
   * Provides the real-time live telemetry stream hook to your dashboard components.
   */
  getTelemetry(): Observable<DashboardData | null> {
    return this.dataSubject.asObservable();
  }

  /**
   * Generates a structural in-memory baseline layout grid of exactly 100 active logs
   * so that when the app boots or exports, it starts with a complete dataset.
   */
  private initializeStaticSeedDeck(): void {

  const now = Date.now();

  this.velocityHistory = [];
  this.pressureHistory = [];
  this.temperatureHistory = [];

  for (let i = 99; i >= 1; i--) {

    const time = new Date(now - i * 1000)
      .toLocaleTimeString([], {
        hour12: false
      });

    this.velocityHistory.push({
      time,
      value: Number(
        (
          this.ORIGINAL_VELOCITY +
          (Math.random() * 6 - 3)
        ).toFixed(1)
      )
    });

    this.pressureHistory.push({
      time,
      value: Math.round(
        this.ORIGINAL_PRESSURE +
        (Math.random() * 12 - 6)
      )
    });

    this.temperatureHistory.push({
      time,
      value: Number(
        (
          this.ORIGINAL_TEMPERATURE +
          (Math.random() * 0.6 - 0.3)
        ).toFixed(1)
      )
    });

  }

}

  /**
   * Starts the infinite, non-blocking polling engine updating variables exactly every 1 second.
   */
    private executeIndefiniteSimulationEngine(): void {

      timer(1000, 1000).subscribe(() => {

        this.updateCycleCount++;

        const currentTime = new Date().toLocaleTimeString([], {
          hour12: false
        });

        if (this.updateCycleCount % 5 === 0) {

          this.currentVelocity +=
            (this.ORIGINAL_VELOCITY - this.currentVelocity) * 0.35;

          this.currentPressure +=
            (this.ORIGINAL_PRESSURE - this.currentPressure) * 0.35;

          this.currentTemperature +=
            (this.ORIGINAL_TEMPERATURE - this.currentTemperature) * 0.35;

        } else {

          this.currentVelocity +=
            this.ORIGINAL_VELOCITY *
            ((Math.random() * 20 - 10) / 100);

          this.currentPressure +=
            this.ORIGINAL_PRESSURE *
            ((Math.random() * 20 - 10) / 100);

          this.currentTemperature +=
            this.ORIGINAL_TEMPERATURE *
            ((Math.random() * 10 - 5) / 100);

        }

        this.currentVelocity = Math.max(
          10,
          Math.min(380, this.currentVelocity)
        );

        this.currentPressure = Math.max(
          200,
          Math.min(1800, this.currentPressure)
        );

        this.currentTemperature = Math.max(
          15,
          Math.min(95, this.currentTemperature)
        );

        const velocity = Number(this.currentVelocity.toFixed(1));
        const pressure = Math.round(this.currentPressure);
        const temperature = Number(this.currentTemperature.toFixed(1));

        this.pushToBoundedRollingDeck(this.velocityHistory, {
          time: currentTime,
          value: velocity
        });

        this.pushToBoundedRollingDeck(this.pressureHistory, {
          time: currentTime,
          value: pressure
        });

        this.pushToBoundedRollingDeck(this.temperatureHistory, {
          time: currentTime,
          value: temperature
        });

        this.publishTelemetry();

      });

    }

  /**
   * Enforces a hard, strict layout boundary of exactly 100 records inside arrays.
   * Evicts the oldest sample pool block whenever limit exceeds 100.
   */
  private pushToBoundedRollingDeck(buffer: TelemetryDataPoint[], dataItem: TelemetryDataPoint): void {
    buffer.push(dataItem);
    if (buffer.length > 100) {
      buffer.shift(); // Evicts the first element, shifting arrays leftward cleanly
    }
  }

  // ─── CLIENT-SIDE DYNAMIC CONVERSION MATRICES (NO BACKEND TRAFFIC REQUESTS) ───
  public convertVelocity(value: number, targetUnit: string): number {
    switch (targetUnit) {
      case 'mm/s': return value * 10.0;//milimeters per second
      case 'm/s': return value / 100.0;//merter per second
      case 'km/h': return value * 0.036;//kilo meter per hour
      case 'ft/s': return value * 0.0328084;//feet per second
      // case 'c/s' : return value *0.1
      default: return value; // Default baseline cm/s
    }
  }

  public convertPressure(value: number, targetUnit: string): number {
    switch (targetUnit) {
      case 'Pa': return value * 100.0;//pascal 
      case 'kPa': return value * 0.1;//kilo pascal
      case 'bar': return value * 0.001;//bar
      case 'psi': return value * 0.0145038;//psi
      case 'atm': return value * 0.000986923;//atmospheric pressure
      default: return value; // Default baseline mbar
    }
  }

  public convertTemperature(value: number, targetUnit: string): number {
    switch (targetUnit) {
      case '°F': return (value * 9.0 / 5.0) + 32.0;//farenhite 
      case 'K': return value + 273.15;//kelvin
      default: return value; // Default baseline °C
    }
  }

  private publishTelemetry(): void {

  if (
    this.velocityHistory.length === 0 ||
    this.pressureHistory.length === 0 ||
    this.temperatureHistory.length === 0
  ) {
    return;
  }

  const velocity = this.velocityHistory.at(-1)!.value;
  const pressure = this.pressureHistory.at(-1)!.value;
  const temperature = this.temperatureHistory.at(-1)!.value;

  const telemetryOutput: DashboardData = {
    timestamp: new Date().toISOString(),

    velocity: {
      currentRawValue: velocity,
      unit: 'cm/s',
      status:
        velocity > 260
          ? 'CRITICAL'
          : velocity > 210
          ? 'WARNING'
          : 'NORMAL',
      history: [...this.velocityHistory]
    },

    pressure: {
      currentRawValue: pressure,
      unit: 'mbar',
      status:
        pressure > 1080 || pressure < 950
          ? 'CRITICAL'
          : pressure > 1030 || pressure < 980
          ? 'WARNING'
          : 'NORMAL',
      history: [...this.pressureHistory]
    },

    temperature: {
      currentRawValue: temperature,
      unit: '°C',
      status:
        temperature > 39.5
          ? 'CRITICAL'
          : temperature > 37.5
          ? 'WARNING'
          : 'NORMAL',
      history: [...this.temperatureHistory]
    }
  };

  this.dataSubject.next(telemetryOutput);
}
}
