import { Component, input } from '@angular/core';

@Component({
  selector: 'app-side-nav',
  imports: [], // Standalone component with zero extra dependency bottlenecks
  templateUrl: './side-nav.html',
  styleUrl: './side-nav.css'
})
export class SideNav {
  // Signal input captures runtime theme context directly from the main workspace root shell
  isLightTheme = input<boolean>(false);
}

