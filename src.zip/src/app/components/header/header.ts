import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-header',
  imports: [],
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {
  // Signal inputs capturing data flows from your application shell
  lastUpdatedTime = input<string>('00:00:00 AM');
  isLightTheme = input<boolean>(false);

  // Output action channels routing user panel events outward
  onExportCSV = output<void>();
  onExportExcel = output<void>();
  onToggleTheme = output<void>();
}
