import { Component, input, effect, inject, computed, ChangeDetectorRef } from '@angular/core';
import { NgApexchartsModule, ApexOptions } from 'ng-apexcharts';
import { Dashboard } from '../dashboard/dashboard';

@Component({
  selector: 'app-trend-chart',
  standalone: true,
  imports: [NgApexchartsModule],
  templateUrl: './trend-chart.html',
  styleUrl: './trend-chart.css',
})
export class TrendChart {
  metricType = input.required<string>(); 
  metricUnit = input<string>(''); 
  seriesData = input.required<{ x: string, y: number }[]>();
  color = input<string>('#38bdf8');

  private parentDashboard = inject(Dashboard);
  private cdr = inject(ChangeDetectorRef); 
  parentDashboardIsLight = computed(() => this.parentDashboard.isLightTheme());

  public chartOptions: ApexOptions = {
    chart: {
      type: 'line',
      height: 300,
      background: 'transparent',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      animations: {
        enabled: true,
        speed: 1,
        dynamicAnimation: { enabled: true, speed: 1 }
      },
      // 🛠️ Toolbar Controls explicitly enabled for Zoom, Zoom-In, Zoom-Out, and Panning mechanics
      toolbar: {
        show: true,
        autoSelected: 'zoom', // Default to zoom interaction tool
        tools: {
          download: false,
          selection: false,
          zoom: true,       // Enables drawing a box to zoom in
          zoomin: true,     // Enables the + button
          zoomout: true,    // Enables the - button
          pan: true,        // Enables the hand tool to drag/pan across timelines
          reset: true       // Enables the home icon button to reset layout view
        }
      }
    },
    stroke: { 
      curve: 'smooth', 
      width: 1.5 
    },
    grid: { 
      show: true,
      borderColor: '#1e293b',
      strokeDashArray: 0,
      xaxis: { lines: { show: false } }, 
      yaxis: { lines: { show: true } },
      padding: { top: 10, right: 20, bottom: 0, left: 20 }
    },
    markers: {
      size: 0 
    },
    xaxis: {
      type: 'category',
      tickAmount: 10, 
      labels: { 
        style: { colors: '#64748b', fontSize: '11px', fontFamily: 'monospace' } 
      },
      title: { 
        text: 'Timestamp', 
        style: { color: '#64748b', fontSize: '11px', fontWeight: 600 } 
      },
      axisBorder: { show: true, color: '#1e293b' },
      axisTicks: { show: false }
    },
    yaxis: {
      tickAmount: 10,
      title: { 
        text: 'Value', 
        style: { color: '#64748b', fontSize: '11px', fontWeight: 600 } 
      },
      labels: { 
        style: { colors: '#64748b', fontSize: '11px', fontFamily: 'monospace' } 
      }
    },
    theme: { mode: 'dark' },
    tooltip: { 
      theme: 'dark',
      x: { show: true }
    },
    series: []
  };

    constructor() {
    effect(() => {
      const isLight = this.parentDashboardIsLight();
      const currentData = this.seriesData(); 
      const type = this.metricType();
      const unit = this.metricUnit(); 

      const formattedType = type.charAt(0).toUpperCase() + type.slice(1);
      const yAxisTitleText = unit ? `${formattedType} (${unit})` : formattedType;
      const unitSuffix = unit ? ` ${unit}` : '';

      this.chartOptions = {
        ...this.chartOptions,
        series: [{
          name: formattedType,
          data: currentData
        }],
        colors: [this.color()],
        theme: { 
          mode: isLight ? 'light' : 'dark' 
        },
        // 🚀 THE FIX: Explicitly enforce type safety on the chart mapping object configuration
        chart: {
          ...this.chartOptions.chart,
          type: 'line', // ✨ Re-declaring this prevents the 'undefined' type-mismatch compilation block
          zoom: {
            enabled: true,
            autoScaleYaxis: true 
          }
        },
        grid: {
          ...this.chartOptions.grid,
          borderColor: isLight ? '#cbd5e1' : '#142037'
        },
        xaxis: {
          ...this.chartOptions.xaxis,
          axisBorder: { 
            show: true, 
            color: isLight ? '#cbd5e1' : '#142037' 
          }
        },
        yaxis: {
          ...this.chartOptions.yaxis,
          title: {
            text: yAxisTitleText,
            style: { color: '#64748b', fontSize: '11px', fontWeight: 600 }
          }
        },
        tooltip: {
          ...this.chartOptions.tooltip,
          theme: isLight ? 'light' : 'dark',
          y: {
            formatter: (val: number) => {
              return `${val}${unitSuffix}`; 
            }
          }
        }
      };

      this.cdr.detectChanges();
    });
  }

}
