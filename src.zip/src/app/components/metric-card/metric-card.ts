import { Component, input, output, computed, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Dashboard } from '../dashboard/dashboard'; // Inject core dashboard container

@Component({
  selector: 'app-metric-card',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './metric-card.html',
  styleUrl: './metric-card.css'
})
export class MetricCard {
  title = input.required<string>();
  displayValue = input.required<string>();
  selectedUnit = input.required<string>();
  units = input.required<string[]>();
  status = input<string>('NORMAL');
  time = input<string>('10:15:05 AM');
  rawValue = input.required<number>();
  maxScale = input<number>(100);
  icon = input<string>('📊'); 

  onUnitChange = output<string>();

  // Inject the parent dashboard container directly
  private parentDashboard = inject(Dashboard);

  // Computes the active parent theme value as a reactive tracking signal
  isLightTheme = computed(() => this.parentDashboard.isLightTheme());

  // Calculate circular stroke filling layout math (Semi-circular representation)
  gaugePercentage = computed(() => {
    return Math.min((this.rawValue() / this.maxScale()) * 100, 100);
  });
}
