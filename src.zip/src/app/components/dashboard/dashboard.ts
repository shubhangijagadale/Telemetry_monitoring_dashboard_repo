import { Component, OnInit, OnDestroy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TelemetryService, DashboardData } from '../../telemetry.service';
import { Header } from '../header/header';
import { MetricCard } from '../metric-card/metric-card';
import { TrendChart } from '../trend-chart/trend-chart';
import { Subscription } from 'rxjs';
import { SideNav } from '../side-nav/side-nav'; 

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, Header, MetricCard, TrendChart, SideNav],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements OnInit, OnDestroy {
  private service = inject(TelemetryService);
  private subscription!: Subscription;

  isLightTheme = signal(false);
  rawTelemetry = signal<DashboardData | null>(null);
  
  velocityUnit = signal('cm/s');
  pressureUnit = signal('mbar');
  temperatureUnit = signal('°C');

  lastUpdatedTime = computed(() => {
    const data = this.rawTelemetry();
    return data ? new Date(data.timestamp).toLocaleTimeString([], { hour12: true }) : '00:00:00 AM';
  });

  displayVelocity = computed(() => {
    const val = this.rawTelemetry()?.velocity.currentRawValue || 0;
    return this.service.convertVelocity(val, this.velocityUnit()).toFixed(1);
  });

  displayPressure = computed(() => {
    const val = this.rawTelemetry()?.pressure.currentRawValue || 0;
    return Math.round(this.service.convertPressure(val, this.pressureUnit())).toString();
  });

  displayTemperature = computed(() => {
    const val = this.rawTelemetry()?.temperature.currentRawValue || 0;
    return this.service.convertTemperature(val, this.temperatureUnit()).toFixed(1);
  });

  velocitySeries = computed(() => {
    return (this.rawTelemetry()?.velocity.history || []).map(pt => ({
      x: pt.time,
      y: parseFloat(this.service.convertVelocity(pt.value, this.velocityUnit()).toFixed(1))
    }));
  });

  pressureSeries = computed(() => {
    return (this.rawTelemetry()?.pressure.history || []).map(pt => ({
      x: pt.time,
      y: Math.round(this.service.convertPressure(pt.value, this.pressureUnit()))
    }));
  });

  temperatureSeries = computed(() => {
    return (this.rawTelemetry()?.temperature.history || []).map(pt => ({
      x: pt.time,
      y: parseFloat(this.service.convertTemperature(pt.value, this.temperatureUnit()).toFixed(1))
    }));
  });

  ngOnInit(): void {
    this.subscription = this.service.getTelemetry().subscribe(data => this.rawTelemetry.set(data));
  }

  toggleTheme(): void { this.isLightTheme.update(v => !v); }

  // exportToCSV(): void {
  //   const data = this.rawTelemetry();
  //   if (!data) return;

  //   const vUnit = this.velocityUnit();
  //   const pUnit = this.pressureUnit();
  //   const tUnit = this.temperatureUnit();
  //   let csv = `Timestamp,Velocity(${vUnit}),Pressure(${pUnit}),Temperature(${tUnit})\n`;

  //   for (let i = 0; i < data.velocity.history.length; i++) {
  //     const convertedV = this.service.convertVelocity(data.velocity.history[i].value, vUnit).toFixed(1);
  //     const convertedP = Math.round(this.service.convertPressure(data.pressure.history[i].value, pUnit));
  //     const convertedT = this.service.convertTemperature(data.temperature.history[i].value, tUnit).toFixed(1);

  //     csv += `${data.velocity.history[i].time},${convertedV},${convertedP},${convertedT}\n`;
  //   }
  //   this.downloadFile(csv, 'text/csv', 'Telemetry_Report.csv');
  // }
// src/app/components/dashboard/dashboard.ts

exportToCSV(): void {
  const data = this.rawTelemetry();
  if (!data) return;

  const vUnit = this.velocityUnit();
  const pUnit = this.pressureUnit();
  const tUnit = this.temperatureUnit();

  // 1. Build the data rows as usual
  let csv = `Timestamp,Velocity(${vUnit}),Pressure(${pUnit}),Temperature(${tUnit})\n`;

  for (let i = 0; i < data.velocity.history.length; i++) {
    const convertedV = this.service.convertVelocity(data.velocity.history[i].value, vUnit).toFixed(1);
    const convertedP = Math.round(this.service.convertPressure(data.pressure.history[i].value, pUnit));
    const convertedT = this.service.convertTemperature(data.temperature.history[i].value, tUnit).toFixed(1);

    csv += `${data.velocity.history[i].time},${convertedV},${convertedP},${convertedT}\n`;
  }

  // 🚀 THE FIX: Prepend the UTF-8 BOM character (\uFEFF) to the array [2]
  // This forces Windows Excel to instantly parse the commas and align the columns perfectly!
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', 'Telemetry_Report.csv');
  link.click();
}

  exportToExcel(): void {
    const data = this.rawTelemetry();
    if (!data) return;

    const vUnit = this.velocityUnit();
    const pUnit = this.pressureUnit();
    const tUnit = this.temperatureUnit();

    let xml = `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Telemetry"><Table>`;
   
    xml += `<Row><Cell><Data ss:Type="String">Timestamp</Data></Cell><Cell><Data ss:Type="String">Velocity (${vUnit})</Data></Cell><Cell><Data ss:Type="String">Pressure (${pUnit})</Data></Cell><Cell><Data ss:Type="String">Temperature (${tUnit})</Data></Cell></Row>`;
    
    for (let i = 0; i < data.velocity.history.length; i++) {
      const convertedV = this.service.convertVelocity(data.velocity.history[i].value, vUnit).toFixed(1);
      const convertedP = Math.round(this.service.convertPressure(data.pressure.history[i].value, pUnit));
      const convertedT = this.service.convertTemperature(data.temperature.history[i].value, tUnit).toFixed(1);

      xml += `<Row><Cell><Data ss:Type="String">${data.velocity.history[i].time}</Data></Cell><Cell><Data ss:Type="Number">${convertedV}</Data></Cell><Cell><Data ss:Type="Number">${convertedP}</Data></Cell><Cell><Data ss:Type="Number">${convertedT}</Data></Cell></Row>`;
    }
    xml += '</Table></Worksheet></Workbook>';
    this.downloadFile(xml, 'application/vnd.ms-excel', 'Telemetry_Report.xls');
  }

  private downloadFile(content: string, type: string, filename: string): void {
    const blob = new Blob([content], { type });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', filename);
    link.click();
  }

  ngOnDestroy(): void { if (this.subscription) this.subscription.unsubscribe(); }
}
