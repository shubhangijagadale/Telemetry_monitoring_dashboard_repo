# Telemetry Monitoring Dashboard

A Windows Desktop Application built using **Angular 22**, **Electron**, and **Express.js** for monitoring telemetry data in real time.

The application communicates with a backend service that simulates telemetry values and displays them using gauges, live trend charts, and a modern monitoring dashboard.

---

# Features

- Real-time telemetry monitoring
- Windows Desktop Application using Electron
- Live dashboard updates every second
- Velocity, Pressure, and Temperature monitoring
- Circular gauges
- Real-time trend charts
- Unit conversion without backend requests
- Light and Dark theme switching
- Auto refresh every second
- Connection status indicator
- Last updated timestamp
- Export telemetry data to CSV
- Export telemetry data to Excel
- Responsive modern dashboard

---

# Technology Stack

## Frontend

- Angular 22
- TypeScript
- RxJS

## Desktop Framework

- Electron

## Backend

- Node.js
- Express.js

## Charts

- ApexCharts
- ng-apexcharts

---

# Prerequisites

Install the following software before running the application.

- Node.js (v20 or later)
- npm
- Angular CLI

Install Angular CLI globally if it is not installed.

```bash
npm install -g @angular/cli
```

---

# Project Installation

## Step 1

Clone the repository.

```bash
ng new <project-name>
git clone <repository-url>
```

## Step 2

Open the project folder.

```bash
cd desktop.app
```

## Step 3

Install all project dependencies.

```bash
npm install
```

---

# Running the Application

## Run Angular Development Server

```bash
npm start
```

or

```bash
ng serve
```

The Angular application will start at

```
http://localhost:4200
```

---

## Run Electron Desktop Application

Open another terminal and run

```bash
npm run electron
```

---

## Run Angular and Electron Together

```bash
npm run electron:dev
```

This command

- Starts Angular Development Server
- Waits until Angular is running
- Automatically launches the Electron desktop application

---

# Build the Application

Build Angular

```bash
npm run build
```

Build Electron

```bash
npm run electron:build
```

---

# Available Scripts

| Command | Description |
|----------|-------------|
| npm install | Install dependencies |
| npm start | Run Angular |
| npm run build | Build Angular |
| npm run watch | Watch mode build |
| npm run electron | Launch Electron |
| npm run electron:dev | Launch Angular + Electron |
| npm run electron:build | Build Angular and launch Electron |
| npm test | Run Unit Tests |

---

# Project Structure

```
desktop.app
│
├── src
│   ├── app
│   ├── assets
│   ├── environments
│
├── main.js
├── package.json
├── angular.json
├── tsconfig.json
├── README.md
```

---

# Application Workflow

```
                    User

                      │

                      ▼

        Electron Desktop Application

                      │

                      ▼

             Angular Frontend

                      │

             HTTP REST API

                      │

                      ▼

          Express.js Backend Service

                      │

                      ▼

        Simulated Telemetry Generator

                      │

                      ▼

 Velocity | Pressure | Temperature
```

---

# Dashboard Overview

The application dashboard provides

- Live telemetry monitoring
- Three circular gauges
- Three real-time trend charts
- Connection status
- Last updated timestamp
- Theme switching
- Unit conversion
- CSV Export
- Excel Export
- Auto refresh every second

---

# Assumptions

- Backend simulates telemetry data.
- Dashboard automatically refreshes every second.
- Unit conversion is performed on the client side.
- Latest telemetry values are displayed in real time.
- Exported data includes collected telemetry values.
- Application is intended for Windows operating systems.

---

# Troubleshooting

## Angular server is not starting

Run

```bash
npm install
```

Then

```bash
npm start
```

---

## Electron window is not opening

Run

```bash
npm run electron
```

---

## Missing Dependencies

Delete the **node_modules** folder.

Run

```bash
npm install
```

---

## Build Errors

Run

```bash
npm run build
```

Check the terminal for build errors.

---

# Future Enhancements

- User Authentication
- Database Integration
- Multiple Device Monitoring
- Alarm Notifications
- Historical Report Generation
- Cloud Deployment

---

# Author

Developed as part of the Angular + Electron Technical Assessment.
