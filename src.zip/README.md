# Telemetry Monitoring Dashboard

## Project Overview

The Telemetry Monitoring Dashboard is a Windows Desktop Application developed using **Angular 22** and **Electron**.

The application simulates real-time telemetry data using an Angular **TelemetryService** and displays Velocity, Pressure, and Temperature through circular gauges and live trend charts. It also supports theme switching, unit conversion, and data export.

---

## Features

- Real-time telemetry monitoring
- Windows Desktop Application using Electron
- Live dashboard updates every second
- Velocity, Pressure, and Temperature monitoring
- Circular gauges
- Live trend charts
- Unit conversion
- Light/Dark theme
- Connection status indicator
- Last updated timestamp
- Export telemetry data to CSV
- Export telemetry data to Excel
- Responsive dashboard

---

## Technology Stack

### Frontend
- Angular 22
- TypeScript
- RxJS

### Desktop Framework
- Electron

### Telemetry Simulation
- Angular TelemetryService
- RxJS BehaviorSubject
- RxJS Timer

### Charts
- ApexCharts
- ng-apexcharts

---

## Prerequisites

- Node.js (v20 or later)
- npm
- Angular CLI

Install Angular CLI:

```bash
npm install -g @angular/cli
```

---

## Installation

### Option 1 – Run the Packaged Application

1. Extract the submitted ZIP file(TelemetryDashboard.Zip).
2. Open the **release-builds** folder.
3. Locate the **TelemetryDashboard.application** file.
4. Double-click **TelemetryDashboard.application** to start the installation.
5. Follow the installation wizard:
   - Click **Next**.
   - Choose the destination folder (or keep the default location).
   - Click **Install**.
6. Once the installation is complete, click **Finish**.
7. Launch the **Telemetry Dashboard** application.
8. The application will begin generating simulated telemetry data.

### Option 2 – Run the Project Locally

1. Open the project folder in Visual Studio Code.
2. Install dependencies:

```bash
npm install
```

---

## Running the Application

Start Angular:

```bash
npm start
```

or

```bash
ng serve
```

Application URL:

```text
http://localhost:4200
```

Launch Electron:

```bash
npm run electron
```

Run Angular and Electron together:

```bash
npm run electron:dev
```

---

## Build Application

```bash
npm run build
```

```bash
npm run electron:build
```

---

## Available Scripts

| Command | Description |
|----------|-------------|
| npm install | Install dependencies |
| npm start | Run Angular |
| npm run build | Build Angular |
| npm run watch | Build in watch mode |
| npm run electron | Launch Electron |
| npm run electron:dev | Launch Angular + Electron |
| npm run electron:build | Build Angular and launch Electron |
| npm test | Run unit tests |

---

## Project Structure

```text
TelemetryDashboard.app
│
├── src
│   ├── app
│   ├── assets
│   └── index,etc
├── release-builds
│   └── TelemetryDashboard.Appliction
├── main.js
├── angular.json
├── package.json
├── tsconfig.json
├── README.md
├── Architecture.md
└── Assumptions.md
```

---

# Submission Notes

The following folders are **not included** in the submitted ZIP file to keep the package size small:

- `node_modules/`
- `dist/`

After extracting the project, install the required dependencies by running:

```bash
npm install
```


If Angular does not start:

```bash
npm start
```

If Electron does not open:

```bash
npm run electron
```
