// main.js
const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,   // Prevents layout breaking on ultra-small windows
    minHeight: 600,
    backgroundColor: '#000000', // Matches your dark theme to prevent white flicker on launch
    show: false, // Prevents visual flash before content is loaded
    
    // 🚀 THE FIX: Sets your custom icon for the taskbar and title window during development
    icon: path.join(__dirname, 'src/assets/icons/icon.ico'), 

    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true
    }
  });

  // Show window smoothly when Angular finishes loading
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });
// Add this mode-switching logic into main.js inside createWindow()
  if (app.isPackaged) {
    mainWindow.loadFile(path.join(__dirname, 'dist/desktop.app/browser/index.html'));
  } else {
    mainWindow.loadURL('http://localhost:4200');
  }

  // mainWindow.loadURL('http://localhost:4200'); // or loadFile('dist/index.html')
}

app.whenReady().then(createWindow);
