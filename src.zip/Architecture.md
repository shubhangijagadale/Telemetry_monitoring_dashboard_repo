# Application Architecture

## Overview

The application follows a component-based architecture using **Angular 22** and **Electron**. Electron packages the application as a native Windows desktop application, while Angular manages the user interface and application logic. A dedicated **TelemetryService** simulates telemetry data and distributes updates to the dashboard components.

---

## Architecture Diagram

```text
                    User
                      │
                      ▼
      Electron Desktop Application
                      │
                      ▼
          Angular 22 Frontend
                      │
                      ▼
            TelemetryService
     (RxJS BehaviorSubject + Timer)
                      │
                      ▼
      Simulated Telemetry Generator
                      │
                      ▼
 Velocity • Pressure • Temperature
                      │
                      ▼
 Dashboard Components (Charts & Gauges)
```

---

## Application Components

- Dashboard Component
- Metric Card Component
- Trend Chart Component
- Header Component
- Side Navigation Component
- Telemetry Service

---

## Frontend (Angular 22)

The frontend is built with **Angular 22** and is responsible for:

- Displaying real-time telemetry values
- Rendering circular gauges for Velocity, Pressure, and Temperature
- Displaying live trend charts using ApexCharts
- Supporting client-side unit conversion
- Providing Light and Dark theme switching
- Displaying connection status and last updated time
- Exporting telemetry data to CSV and Excel

---

## Desktop Application (Electron)

Electron is used to package the Angular application as a native Windows desktop application. This allows users to run the application as a standalone desktop application without using a web browser.

---

## Telemetry Simulation Service

Instead of using a separate backend server, the application uses a custom Angular **TelemetryService** to simulate telemetry data.

The service is responsible for:

- Generating telemetry values every second using an RxJS `timer`
- Publishing updates through a `BehaviorSubject`
- Maintaining the latest 100 telemetry records
- Simulating realistic fluctuations in telemetry values
- Calculating telemetry status (Normal, Warning, Critical)
- Performing client-side unit conversion

This approach keeps the application lightweight while demonstrating real-time telemetry monitoring.

---

## Data Flow

1. The **TelemetryService** generates simulated telemetry data every second.
2. Updated telemetry values are published using `BehaviorSubject`.
3. Dashboard components subscribe to the telemetry data stream.
4. Gauges, charts, and status indicators update automatically.
5. Users can switch measurement units without requesting additional data.

---

# Technical Decisions

- **Angular 22:** Chosen for its component-based architecture, TypeScript support, and maintainable code structure.
- **Electron:** Used to package the Angular application as a native Windows desktop application.
- **TelemetryService:** Implements real-time telemetry simulation using RxJS (`BehaviorSubject` and `timer`), eliminating the need for a separate backend.
- **ApexCharts:** Selected for responsive real-time charts with zoom, pan, and tooltip support.
- **Client-Side Unit Conversion:** Unit conversions are performed within the Angular service, providing instant updates without additional data requests.
