Following assumptions are made during implementation of Telemetry Monitoring Dashboard application: 

- Backend simulates telemetry data. 

- Unit conversion is performed on the client side. 

- Latest telemetry values are displayed in real time. 

- Exported data includes collected telemetry values. 

- Default theme is Dark. 

